import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'DetailScreen.dart';

import 'dart:math' as math;

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _controller = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _animationController.dispose();
    super.dispose();
  }

  // Função para adicionar dados ao Firestore
  void _addData() async {
    String text = _controller.text;
    print("Tentando adicionar: $text"); // Debugging
    if (text.isNotEmpty) {
      _animationController.forward(from: 0.0);  // Inicia a animação de rotação
      try {
        await _firestore.collection('data').add({'text': text});  // Adiciona o texto ao Firestore
        print("Adicionado com sucesso!"); // Debugging
      } catch (e) {
        print("Erro ao adicionar: $e"); // Debugging
      }
      _controller.clear();  // Limpa o campo de entrada
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Flutter Firebase App'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: 'Enter Data'),
            ),
            SizedBox(height: 20),
            IconButton(
              icon: AnimatedBuilder(
                animation: _animationController,
                child: Icon(Icons.autorenew),
                builder: (context, child) {
                  return Transform.rotate(
                    angle: _animationController.value * 2 * math.pi,
                    child: child,
                  );
                },
              ),
              iconSize: 50,
              onPressed: _addData,
            ),
            SizedBox(height: 20),
            Expanded(
              child: StreamBuilder(
                stream: _firestore.collection('data').snapshots(),
                builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                  if (!snapshot.hasData) {
                    return Center(child: CircularProgressIndicator());
                  }
                  return ListView(
                    children: snapshot.data!.docs.map((doc) {
                      return ListTile(
                        title: Text(doc['text']),
                        onTap: () {
                          // Navegar para a DetailScreen com o ID do documento
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailScreen(docId: doc.id),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
