import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'HomeScreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: "AIzaSyAn-n6slZMD9LT_bDbD70VnEr1NQHDp9g0",
      authDomain: "projeto-web-7242d.firebaseapp.com",
      projectId: "projeto-web-7242d",
      storageBucket: "projeto-web-7242d.firebasestorage.app",
      messagingSenderId: "320173349787",
      appId: "1:320173349787:web:66f31d50c225e87c74df3e",
      measurementId: "G-79MTF4KC3N",
    ),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Firebase App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: HomeScreen(),
    );
  }
}
