import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DetailScreen extends StatelessWidget {
  final String docId;

  DetailScreen({required this.docId});

  @override
  Widget build(BuildContext context) {
    final DocumentReference documentRef = FirebaseFirestore.instance.collection('data').doc(docId);

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Screen'),
      ),
      body: FutureBuilder<DocumentSnapshot>(
        future: documentRef.get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final data = snapshot.data!.data() as Map<String, dynamic>;
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(
                  'Data: ${data['text']}',
                  style: TextStyle(fontSize: 24),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Go Back'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
